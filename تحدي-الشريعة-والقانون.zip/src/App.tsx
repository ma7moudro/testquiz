import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Trophy, 
  CheckCircle2, 
  XCircle, 
  RotateCcw, 
  BookOpen, 
  Gavel,
  Star,
  Target,
  Sparkles,
  Zap
} from 'lucide-react';

interface Question {
  id: number;
  text: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

const questions: Question[] = [
  {
    id: 1,
    text: "وفقاً للمادة الثانية من الدستور المصري، ما هي مكانة الشريعة الإسلامية؟",
    options: ["هي المصدر الثانوي للتشريع", "هي المصدر الرئيسي للتشريع", "هي مصدر استرشادي غير ملزم", "هي المصدر الوحيد للتشريع الجنائي فقط"],
    correctAnswer: 1,
    explanation: "المادة الثانية من الدستور المصري تنص على أن مبادئ الشريعة الإسلامية هي المصدر الرئيسي للتشريع."
  },
  {
    id: 2,
    text: "ماذا يترتب على إصدار المشرع لقانون يخالف مبادئ الشريعة الإسلامية؟",
    options: ["يُطبق القانون مؤقتاً لحين تعديله", "يُعرض القانون للطعن بعدم الدستورية", "يُعدل تلقائياً من قبل السلطة التنفيذية", "يصبح نافذاً لأنه صادر عن السلطة التشريعية"],
    correctAnswer: 1,
    explanation: "بما أن الشريعة هي المصدر الرئيسي بنص الدستور، فإن أي قانون يخالفها يعتبر مخالفاً للدستور ويجوز الطعن عليه."
  },
  {
    id: 3,
    text: "في التطبيق القضائي، ما المقصود بـ 'مبادئ الشريعة' التي لا يجوز الخروج عنها؟",
    options: ["التفاصيل الفقهية الدقيقة لكل مذهب", "الأحكام الواردة في المذهب الحنفي فقط", "القواعد الكلية والأسس العامة التي بنيت عليها الشريعة", "الأحكام المتعلقة بالعبادات حصراً"],
    correctAnswer: 2,
    explanation: "المقصود هي الأسس العامة والقواعد الكلية القطعية الثبوت والدلالة."
  },
  {
    id: 4,
    text: "عند ترتيب مصادر القانون المدني، إذا لم يجد القاضي نصاً قانونياً أو عرفاً، فإلى ماذا يرجع؟",
    options: ["إلى أحكام المحاكم السابقة (السوابق القضائية)", "إلى مبادئ الشريعة الإسلامية كمصدر عام احتياطي", "إلى القانون الدولي", "يمتنع عن الحكم لعدم وجود نص"],
    correctAnswer: 1,
    explanation: "المادة الأولى من القانون المدني المصري تضع الشريعة الإسلامية كمصدر احتياطي بعد التشريع والعرف."
  },
  {
    id: 5,
    text: "أي المذاهب الفقهية كان له الحضور الأقوى تاريخياً في ميدان الأحوال الشخصية والتطبيق القضائي في مصر؟",
    options: ["المذهب المالكي", "المذهب الشافعي", "المذهب الحنبلي", "المذهب الحنفي"],
    correctAnswer: 3,
    explanation: "المذهب الحنفي هو المذهب الذي اعتمد رسمياً في القضاء المصري منذ العهد العثماني في مسائل الأحوال الشخصية."
  },
  {
    id: 6,
    text: "لفهم المصطلحات الشرعية الواردة في القرآن والسنة فهماً صحيحاً، يجب الرجوع أولاً إلى:",
    options: ["العرف المعاصر", "التفاسير القانونية الحديثة", "لسان العرب كما فهمها العرب في زمن التنزيل", "القوانين الوضعية المقارنة"],
    correctAnswer: 2,
    explanation: "لأن القرآن والسنة نزلا بلسان عربي مبين، فالفهم الصحيح يبدأ من اللغة الأم وقت النزول."
  },
  {
    id: 7,
    text: "ما هو المعنى اللغوي لكلمة 'شريعة' في الاستعمال العربي؟",
    options: ["العقوبات والجزاءات", "الطريقة أو الطريق المستقيم في الدين", "القواعد المكتوبة في الدستور", "العادات والتقاليد المجتمعية"],
    correctAnswer: 1,
    explanation: "اللغة العربية تشير للشريعة بأنها مورد الماء أو الطريق المستقيم."
  },
  {
    id: 8,
    text: "لماذا يحتاج المجتمع إلى الشرائع والقوانين؟",
    options: ["لأن العلاقات بين الناس تحتاج إلى تنظيم وضبط لاختلاف عقولهم وميولهم", "لتقييد الحريات الشخصية للأفراد", "لتوحيد أفكار ومعتقدات جميع البشر", "لفرض الضرائب على المواطنين"],
    correctAnswer: 0,
    explanation: "التنظيم ضرورة اجتماعية لمنع الفوضى وتضارب المصالح."
  },
  {
    id: 9,
    text: "ماذا تُسمى القواعد التي تكون من وضع البشر واجتهادهم من غير وحي مُنزل؟",
    options: ["شرائع سماوية", "شرائع دينية", "شرائع وضعية", "أحكام عقائدية"],
    correctAnswer: 2,
    explanation: "وضعية لأن البشر هم من 'وضعوها' باجتهادهم."
  },
  {
    id: 10,
    text: "ما هو المبدأ المتعلق بـ 'الجهل بالقانون' في الشريعة الإسلامية لمن يعيش في بيئة مسلمة؟",
    options: ["الجهل بالقانون يُعذر به الجميع بلا استثناء", "لا يكون الجهل بالشريعة عذراً لمن لديه القدرة على التعلم والسؤال", "يُعذر الجاهل فقط في مسائل المعاملات المالية", "الجهل بالشريعة يسقط العقوبة في كل الحالات"],
    correctAnswer: 1,
    explanation: "العلم بالأحكام واجب على المستطيع، والتقصير في التعلم لا يسقط المسؤولية."
  },
  {
    id: 11,
    text: "ما هو تعريف 'الشريعة' في الاصطلاح؟",
    options: ["مجموعة العادات التي اتفق عليها الناس", "مجموعة الأحكام التي شرعها الله لعباده وأبلغهم إياها عن طريق رسول", "القواعد التي يضعها الحاكم لتنظيم شؤون الدولة", "الأحكام المستنبطة من القوانين الأجنبية"],
    correctAnswer: 1,
    explanation: "هذا هو التعريف الاصطلاحي الدقيق الذي يفرقها عن القوانين الوضعية."
  },
  {
    id: 12,
    text: "ماذا يعني لفظ 'الإسلام' في أصله اللغوي؟",
    options: ["السلام وعدم الحرب", "الصلاة والصيام", "الخضوع والاستسلام والانقياد لإله واحد", "الإيمان بالملائكة والكتب"],
    correctAnswer: 2,
    explanation: "أسلم بمعنى استسلم وانقاد لله الواحد."
  },
  {
    id: 13,
    text: "أي من أنواع الأحكام التالية لا تعتبر محلاً للدراسة في كلية الحقوق لارتباطها بعلم الكلام؟",
    options: ["الأحكام العملية", "الأحكام الأخلاقية", "الأحكام العقائدية (الاعتقادية)", "أحكام المعاملات"],
    correctAnswer: 2,
    explanation: "الأحكام العقائدية تدرس في كليات أصول الدين، بينما الحقوق تهتم بالأحكام العملية والأخلاقية أحياناً."
  },
  {
    id: 14,
    text: "ما هي السمة الأساسية للأحكام العقائدية والأخلاقية عبر جميع الرسالات السماوية؟",
    options: ["تتغير بتغير الزمان والمكان", "ثابتة لا تتغير باختلاف الزمان والمكان", "تختلف من نبي إلى آخر", "خاضعة لاجتهاد البشر"],
    correctAnswer: 1,
    explanation: "التوحيد ومكارم الأخلاق (مثل الصدق) قيم ثابتة لا تتغير بتغير الزمن."
  },
  {
    id: 15,
    text: "ما هي 'الأحكام العملية (التكليفية)' في الشريعة الإسلامية؟",
    options: ["هي ما يتعلق بإيمان الإنسان بالله واليوم الآخر", "هي الفضائل مثل الصدق والعدل", "هي ما يتعلق بأعمال الجوارح وسلوك الإنسان الظاهر", "هي الأحكام الخاصة بالملائكة والغيبيات"],
    correctAnswer: 2,
    explanation: "العمل الجوارحي هو السلوك الظاهر للإنسان، وهو ما ينظمه التشريع."
  },
  {
    id: 16,
    text: "تنقسم الأحكام العملية إلى قسمين رئيسيين، هما:",
    options: ["جنائية ومدنية", "عبادات ومعاملات", "عقائدية وأخلاقية", "سماوية ووضعية"],
    correctAnswer: 1,
    explanation: "العبادات تنظم علاقة الإنسان بربه، والمعاملات تنظم علاقة الإنسان بغيره."
  },
  {
    id: 17,
    text: "ما هو الوحي 'غير المتلو' الذي يُعتبر مصدراً تشريعياً يستخرج منه الأحكام؟",
    options: ["القرآن الكريم", "الإجماع", "القياس", "السنة النبوية"],
    correctAnswer: 3,
    explanation: "القرآن هو الوحي المتلو، والسنة هي الوحي غير المتلو (بيان الرسول صلى الله عليه وسلم)."
  },
  {
    id: 18,
    text: "ما هي منهجية الشريعة في مجال المعاملات المالية؟",
    options: ["تذكر كل جزئية وتفصيلة محتملة الحدوث", "تمنع الاجتهاد تماماً في الأمور المالية", "تضع قواعد عامة وتترك التفاصيل للاجتهاد في ضوء هذه القواعد", "تحرم جميع أنواع المعاملات التجارية المبتكرة"],
    correctAnswer: 2,
    explanation: "المرونة في المعاملات المالية تقتضي وضع كليات عامة لاستيعاب المستجدات."
  },
  {
    id: 19,
    text: "لماذا وضعت الشريعة ضوابط خاصة ببعض السلع كالذهب والفضة؟",
    options: ["لأنها معادن رخيصة الثمن", "نظراً لصفتهما النقدية/الثمنية وحماية الناس من الربا", "ليمنع الناس من التجارة فيها تماماً", "لأنها تستخدم في الزينة فقط"],
    correctAnswer: 1,
    explanation: "خطورة هذه السلع تكمن في قيمتها النقدية مما يجعلها محلاً للربا إذا لم تضبط."
  },
  {
    id: 20,
    text: "ما هو موقف الشريعة الإسلامية من الأعراف والعادات التي كانت سائدة قبلها في الجاهلية؟",
    options: ["ألغتها وهدمتها جميعاً بلا استثناء", "أقرتها جميعاً واعتبرتها جزءاً من الدين", "لم تتدخل فيها وتركتها للناس", "جمعت بين الإقرار والتعديل والإلغاء"],
    correctAnswer: 3,
    explanation: "أقرت الشريعة الطيب من العادات، وهذبت ما يحتاج تهذيب، وألغت الفاسد منها."
  }
];

export default function App() {
  const [gameState, setGameState] = useState<'intro' | 'playing' | 'results'>('intro');
  const [currentIdx, setCurrentIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [blockStatus, setBlockStatus] = useState<('locked' | 'correct' | 'wrong' | 'current')[]>(
    new Array(questions.length).fill('locked').map((_, i) => (i === 0 ? 'current' : 'locked'))
  );
  
  const [projectile, setProjectile] = useState<{ x: number, y: number, active: boolean }>({ x: 0, y: 0, active: false });
  const blockRefs = useRef<(HTMLDivElement | null)[]>([]);
  const cannonRef = useRef<HTMLDivElement>(null);

  const currentQuestion = questions[currentIdx];

  const handleOptionSelect = (idx: number) => {
    if (showFeedback) return;
    
    setSelectedOption(idx);
    const correct = idx === currentQuestion.correctAnswer;
    
    // Animate Projectile toward the block at the bottom
    if (cannonRef.current && blockRefs.current[currentIdx]) {
      const cannonRect = cannonRef.current.getBoundingClientRect();
      const targetRect = blockRefs.current[currentIdx]!.getBoundingClientRect();
      
      const targetX = targetRect.left + targetRect.width / 2 - (cannonRect.left + cannonRect.width / 2);
      const targetY = targetRect.top + targetRect.height / 2 - (cannonRect.top + cannonRect.height / 2);

      setProjectile({ x: targetX, y: targetY, active: true });

      setTimeout(() => {
        setProjectile(p => ({ ...p, active: false }));
        setBlockStatus(prev => {
          const next = [...prev];
          next[currentIdx] = correct ? 'correct' : 'wrong';
          if (currentIdx + 1 < questions.length) next[currentIdx + 1] = 'current';
          return next;
        });
        if (correct) setScore(s => s + 1);
        setShowFeedback(true);
      }, 500); 
    }
  };

  const handleNext = () => {
    if (currentIdx < questions.length - 1) {
      setCurrentIdx(i => i + 1);
      setSelectedOption(null);
      setShowFeedback(false);
    } else {
      setGameState('results');
    }
  };

  const restart = () => {
    setCurrentIdx(0);
    setScore(0);
    setSelectedOption(null);
    setShowFeedback(false);
    setBlockStatus(new Array(questions.length).fill('locked').map((_, i) => (i === 0 ? 'current' : 'locked')));
    setGameState('intro');
  };

  return (
    <div className="min-h-screen font-serif text-right p-4 md:p-6 flex flex-col items-center bg-emerald-950 text-slate-100 overflow-hidden" dir="rtl">
      
      <AnimatePresence mode="wait">
        {gameState === 'intro' && (
          <motion.div 
            key="intro"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.1 }}
            className="flex-1 flex flex-col items-center justify-center text-center max-w-2xl px-6"
          >
            <motion.div 
               animate={{ rotate: [0, 10, -10, 0] }}
               transition={{ repeat: Infinity, duration: 4 }}
               className="mb-8 p-10 bg-yellow-500 rounded-[40px] shadow-2xl shadow-yellow-500/20"
            >
              <Gavel size={80} className="text-emerald-900" />
            </motion.div>
            <h1 className="text-6xl font-black mb-6 text-yellow-500 leading-tight">حطّم جدار الجهل</h1>
            <p className="text-2xl text-slate-300 mb-10 font-sans leading-relaxed">
              أهلاً بك في تحدي الشريعة والقانون. 
              أمامك <span className="text-white font-bold">{questions.length} عائقاً</span> من الجهل. 
              أجب عن الأسئلة بدقة لتطلق قذائف المعرفة وتهدم الجدار!
            </p>
            <button 
              onClick={() => setGameState('playing')}
              className="px-14 py-6 bg-yellow-500 text-emerald-950 rounded-2xl font-black text-2xl hover:bg-yellow-400 transition-all hover:scale-105 active:scale-95 shadow-xl shadow-yellow-500/30 flex items-center gap-4"
            >
              <Zap size={32} />
              ابدأ التدمير الآن
            </button>
          </motion.div>
        )}

        {gameState === 'playing' && (
          <motion.div 
            key="playing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="w-full max-w-6xl flex flex-col h-full gap-4 relative"
          >
            {/* Header Cannon Container */}
            <div className="flex justify-center pt-2">
              <div ref={cannonRef} className="relative group">
                <div className="bg-yellow-500 p-4 rounded-3xl text-emerald-900 shadow-2xl shadow-yellow-500/40 relative z-10 transition-transform group-hover:scale-110">
                   <Gavel size={32} />
                </div>
                {/* Projectile */}
                {projectile.active && (
                  <motion.div 
                    initial={{ x: 0, y: 0, scale: 1, opacity: 1 }}
                    animate={{ x: projectile.x, y: projectile.y, scale: 0.2, opacity: 0.8 }}
                    transition={{ duration: 0.5, ease: "circIn" }}
                    className="absolute top-1/2 left-1/2 -mt-4 -ml-4 w-8 h-8 bg-yellow-300 rounded-full blur-[2px] z-20 shadow-[0_0_15px_#fcd34d]"
                  />
                )}
                {/* Score Cloud */}
                <div className="absolute -left-20 top-0 bg-white/5 backdrop-blur-md px-4 py-2 rounded-xl border border-white/10 flex items-center gap-2">
                   <Trophy size={16} className="text-yellow-500" />
                   <span className="font-bold text-lg">{score}</span>
                </div>
              </div>
            </div>

            {/* Question Card */}
            <div className="flex-1 flex flex-col items-center justify-center min-h-0">
               <div className="w-full max-w-4xl bg-white/10 backdrop-blur-2xl border border-white/20 p-8 rounded-[40px] shadow-2xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-6 opacity-5 pointer-events-none">
                     <BookOpen size={160} />
                  </div>
                  
                  <div className="text-center mb-8">
                     <span className="bg-white/10 px-4 py-1 rounded-full text-xs font-sans tracking-widest text-yellow-500 mb-2 inline-block">QUESTION {currentIdx + 1}</span>
                     <h2 className="text-2xl md:text-4xl font-bold leading-tight line-clamp-3">{currentQuestion.text}</h2>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {currentQuestion.options.map((option, idx) => {
                      const isCorrectCorrect = idx === currentQuestion.correctAnswer;
                      const isSelected = selectedOption === idx;
                      
                      let btnStateClass = "bg-white/5 border-white/10 hover:bg-white/10 hover:border-yellow-500/50";
                      if (showFeedback) {
                        if (isCorrectCorrect) btnStateClass = "bg-emerald-500 border-emerald-400 text-white shadow-lg shadow-emerald-500/30";
                        else if (isSelected) btnStateClass = "bg-rose-500 border-rose-400 text-white grayscale-[0.5]";
                        else btnStateClass = "opacity-20 grayscale cursor-default";
                      }

                      return (
                        <motion.button
                          key={idx}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: idx * 0.1 }}
                          onClick={() => handleOptionSelect(idx)}
                          disabled={showFeedback}
                          className={`p-5 rounded-2xl border-2 text-right text-lg transition-all flex items-center justify-between gap-4 ${btnStateClass}`}
                        >
                          <span className="font-sans leading-snug">{option}</span>
                          {showFeedback && isCorrectCorrect && <CheckCircle2 className="shrink-0" />}
                          {showFeedback && isSelected && !isCorrectCorrect && <XCircle className="shrink-0" />}
                        </motion.button>
                      );
                    })}
                  </div>

                  <AnimatePresence>
                    {showFeedback && (
                      <motion.div 
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        className="mt-6 pt-6 border-t border-white/10"
                      >
                         <div className="p-4 bg-emerald-500/10 rounded-2xl border border-emerald-500/20 mb-6 flex items-start gap-4">
                            <Sparkles className="text-yellow-500 shrink-0 mt-1" size={20} />
                            <p className="text-sm font-sans text-slate-300 leading-relaxed md:text-base">{currentQuestion.explanation}</p>
                         </div>
                         <button 
                           onClick={handleNext}
                           className="w-full py-5 bg-yellow-500 text-emerald-950 rounded-2xl font-black text-2xl hover:bg-yellow-400 transition-transform active:scale-95 shadow-xl"
                         >
                           {currentIdx === questions.length - 1 ? 'تحطيم الجدار النهائي' : 'السؤال التالي'}
                         </button>
                      </motion.div>
                    )}
                  </AnimatePresence>
               </div>
            </div>

            {/* Bottom Blocks Grid */}
            <div className="mt-auto px-2 pb-6">
               <div className="grid grid-cols-10 gap-2 max-w-4xl mx-auto">
                  {blockStatus.map((status, i) => (
                    <div 
                      key={i} 
                      ref={el => blockRefs.current[i] = el}
                      className="relative h-14 md:h-20"
                    >
                      <motion.div
                        initial={false}
                        animate={
                          status === 'correct' ? { backgroundColor: "#10b981", scale: 1 } :
                          status === 'wrong' ? { backgroundColor: "#f43f5e", scale: 0.9, opacity: 0.5 } :
                          status === 'current' ? { scale: [1, 1.1, 1], backgroundColor: "#eab308", rotate: [0, 5, -5, 0] } :
                          { backgroundColor: "rgba(255,255,255,0.05)" }
                        }
                        transition={status === 'current' ? { repeat: Infinity, duration: 2 } : { duration: 0.3 }}
                        className={`absolute inset-0 rounded-xl border border-white/10 flex items-center justify-center shadow-lg transition-colors overflow-hidden`}
                      >
                         {status === 'correct' && <Star size={18} fill="white" className="text-white drop-shadow-[0_0_5px_rgba(255,255,255,0.5)]" />}
                         {status === 'wrong' && <XCircle size={18} className="opacity-50" />}
                         {status === 'current' && <Target size={20} className="animate-spin-slow opacity-50" />}
                         {status === 'locked' && <div className="w-1.5 h-1.5 bg-white/20 rounded-full" />}
                         
                         {/* Shatter effect on correct */}
                         {status === 'correct' && (
                           <motion.div 
                             initial={{ opacity: 1, scale: 1 }}
                             animate={{ opacity: 0, scale: 2 }}
                             className="absolute inset-0 bg-white/50 z-10"
                           />
                         )}
                      </motion.div>
                    </div>
                  ))}
               </div>
            </div>
          </motion.div>
        )}

        {gameState === 'results' && (
          <motion.div 
            key="results"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="flex-1 flex flex-col items-center justify-center text-center max-w-2xl px-6"
          >
            <div className="relative mb-12">
               <motion.div 
                 animate={{ rotate: 360 }}
                 transition={{ repeat: Infinity, duration: 25, ease: "linear" }}
                 className="absolute inset-0 scale-150 opacity-20"
               >
                 <Target size={240} className="text-yellow-500" />
               </motion.div>
               <div className="bg-yellow-500 p-10 rounded-[50px] shadow-2xl relative z-10 text-emerald-950">
                  <Trophy size={100} />
               </div>
            </div>

            <h2 className="text-6xl font-black mb-6">تم تدمير الجهل!</h2>
            <div className="bg-white/5 p-8 rounded-3xl border border-white/10 mb-10 w-full">
               <div className="grid grid-cols-2 gap-8">
                  <div>
                    <p className="text-sm font-sans opacity-50 mb-2 uppercase tracking-widest">Score</p>
                    <p className="text-5xl font-bold text-yellow-500">{score} <span className="text-xl opacity-30">/ {questions.length}</span></p>
                  </div>
                  <div>
                    <p className="text-sm font-sans opacity-50 mb-2 uppercase tracking-widest">Accuracy</p>
                    <p className="text-5xl font-bold text-emerald-400">{Math.round((score/questions.length)*100)}%</p>
                  </div>
               </div>
            </div>

            <p className="text-2xl text-slate-300 mb-12 leading-relaxed italic">
               "لقد نجحت في كشف الغطاء عن جوهر القانون المصري المستمد من الشريعة السمحاء."
            </p>

            <button 
              onClick={restart}
              className="flex items-center gap-4 bg-white text-emerald-950 px-12 py-6 rounded-2xl font-black text-2xl hover:bg-yellow-500 transition-all hover:scale-105 active:scale-95"
            >
              <RotateCcw size={32} />
              تحطيم الجدار مرة أخرى
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
